# TODO: asking the questions
# TODO: checking if the answer was correct
# TODO: checking if we're the end of the quiz

class QuizBrain: 
    def __init__(self, q_list) -> None:
        self.question_number = 0  #cada vez que creamos un nuevo QuizBrain se establece en 0 el atributo creado.
        self.question_list = q_list #input value
        self.score = 0
        
    def check_answer(self,user_answer, correct_answer):
        """Check if the answer was correct.
        """
        if user_answer.lower() == correct_answer.lower():
            self.score +=1
            print("Right")
        else:
            print("wrong.")
        print(f"The correct answer was: {correct_answer}")
        print(f"Your current score is: {self.score}/{self.question_number}" )
        print("\n")
            
            
    def still_has_questions(self):
        """Functions that returns True if exist questions or False isn't.

        Returns:
            Boolean: True if number of questions is less than len of list.
        """
        return self.question_number < len(self.question_list) 
        #if self.question_number < len(self.question_list) :
        #    return True
        #return False
    
    def next_question(self):
        
        current_question = self.question_list[self.question_number]
        self.question_number += 1
        user_answer = input(f"Q.{self.question_number }:{current_question.text} (True/False)")
        self.check_answer(user_answer,current_question.answer)
                   

