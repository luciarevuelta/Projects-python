from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

question_bank = [] #lista vacía donde almacenaré los valores

for question in question_data: #bucle que recorre todas las preguntas propuestas
    list_question = Question(question["text"],question["answer"]) #creo el objeto lista_question
    question_bank.append(list_question)
    
#print(question_bank)   
#print(question_bank[0].text)
 
quiz = QuizBrain(question_bank) #creo el objeto quiz de la clase QuizBrain.

while quiz.still_has_questions():
    quiz.next_question() # le pasamos el método.
 
print("You have completed the quiz")
print(f"Your final score was: 10/ {len(question_bank)}")