#Create a Question class with an __init()__ method with two attributes: text and answer.


class Question: #creo la clase Pregunta
    def __init__(self,q_text,q_answer): # Creo el constructor de la clase 
        self.text = q_text
        self.answer = q_answer
    
#new_q = Question("2+3","True") #creo el objeto de la clase al que le pasamos dos parámetros
#print(new_q.text)
#print(new_q.answer)


        